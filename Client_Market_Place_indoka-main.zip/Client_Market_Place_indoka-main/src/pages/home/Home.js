import React, { Fragment, useRef } from "react";
import SEO from "../../components/seo";
import Layout from "../../layouts/Layout";
import HeroSlider from "../../wrappers/hero-slider/HeroSlider";
import SectionTitleImage from "../../components/section-title/SectionTitleImage";
import {Link} from "react-router-dom";
import TestimonialTwo from "../../wrappers/testimonial/TestimonialTwo";
import FeatureIconSeven from "../../wrappers/feature-icon/FeatureIconSeven";
import BrandLogoSliderFive from "../../wrappers/brand-logo/BrandLogoSliderFive";
import {Cloudinary, CloudinaryImage} from "@cloudinary/url-gen";
import {AdvancedImage} from '@cloudinary/react';

const Home = () => {
    // Create a Cloudinary instance and set your cloud name.
    const ref = useRef(null);
    const doClick = () => ref.current?.scrollIntoView({behavior: 'smooth'})

    const cld = new Cloudinary({
        cloud: {
            cloudName: 'dkmtnqj5a'
        }
    });

    return (
        <Fragment>
            <SEO
                title="Indoka"
                titleTemplate="Accueil"
                description="Label Santé & Beauté des Laboratoires Indoka proposant des produits 100% Naturels,compléments alimentaires Beauté, Santé et Vitalité."
            />
            <Layout>
                {/* hero slider */}
                <HeroSlider doClick={doClick} />

                {/* section title */}
                <SectionTitleImage
                    elem={ref}
                    spaceTopClass="pt-95"
                    spaceBottomClass="pb-90"
                />

                {/* grid banner */}
                <div className="product-area hm6-section-padding pt-95 pb-80">
                    <div className="container-fluid">
                        <div className="row">
                            <div className="col-lg-6">
                                <div className="product-wrap-4 mb-20">
                                    <Link to={process.env.PUBLIC_URL + "/"}>
                                        <AdvancedImage cldImg={cld.image('prod-1_jutj6n').quality('auto')} />
                                    </Link>
                                    <div className="product-content-4 text-center position-1">
                                        <h4 className="text-white">
                                            <Link
                                                className="text-white"
                                                to={process.env.PUBLIC_URL + "/"}>
                                                Qualité Supérieure <br />
                                                Supplément
                                            </Link>
                                        </h4>
                                    </div>
                                </div>
                            </div>
                            <div className="col-lg-3">
                                <div className="product-wrap-4 mb-20">
                                    <Link to={process.env.PUBLIC_URL + "/"}>
                                        <AdvancedImage cldImg={cld.image('prod-2_ui6xnh').quality('auto')} />
                                    </Link>
                                    <div className="product-content-4 text-center position-1">
                                        <h4 className="text-white">
                                            <Link
                                                className="text-white"
                                                to={process.env.PUBLIC_URL + "/"}>
                                                Comprimés  <br />
                                                Compressés
                                            </Link>
                                        </h4>
                                    </div>
                                </div>
                            </div>
                            <div className="col-lg-3">
                                <div className="product-wrap-4 mb-20">
                                    <Link to={process.env.PUBLIC_URL + "/"}>
                                        <AdvancedImage cldImg={cld.image('prod-3_bklqhy').quality('auto')} />
                                    </Link>
                                    <div className="product-content-4 text-center position-3">
                                        <h4 className="text-white">
                                            <Link
                                                className="text-white"
                                                to={process.env.PUBLIC_URL + "/"}>
                                                Gélules
                                            </Link>
                                        </h4>
                                    </div>
                                </div>
                            </div>
                            <div className="col-lg-3">
                                <div className="product-wrap-4 mb-20">
                                    <Link to={process.env.PUBLIC_URL + "/"}>
                                        <AdvancedImage cldImg={cld.image('prod-4_f3vrme').quality('auto')} />
                                    </Link>
                                    <div className="product-content-4 product-content-center position-2">
                                        <h4 className="text-white">
                                            <Link
                                                className="text-white"
                                                to={process.env.PUBLIC_URL + "/"}>
                                                Poudre
                                            </Link>
                                        </h4>
                                    </div>
                                </div>
                            </div>
                            <div className="col-lg-6">
                                <div className="product-wrap-4 mb-20">
                                    <Link to={process.env.PUBLIC_URL + "/"}>
                                        <AdvancedImage cldImg={cld.image('prod-5_o3lebg').quality('auto')} />
                                    </Link>
                                    <div className="product-content-4 product-content-center position-2">
                                        <h4>
                                            <Link
                                                className="text-white"
                                                to={process.env.PUBLIC_URL + "/"}>
                                                Gélifiés
                                            </Link>
                                        </h4>
                                    </div>
                                </div>
                            </div>
                            <div className="col-lg-3">
                                <div className="product-wrap-4 mb-20">
                                    <Link to={process.env.PUBLIC_URL + "/"}>
                                        <AdvancedImage cldImg={cld.image('prod-6_thvqcv').quality('auto')} />
                                    </Link>
                                    <div className="product-content-4 product-content-center position-2">
                                        <h4>
                                            <Link
                                                className="text-white"
                                                to={process.env.PUBLIC_URL + "/"}>
                                                Capsules  <br />
                                                Molles
                                            </Link>
                                        </h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* testimonial */}
                <TestimonialTwo
                    spaceTopClass="pt-100"
                    spaceBottomClass="pb-95"
                    spaceLeftClass="ml-70"
                    spaceRightClass="mr-70"
                    bgColorClass="bg-gray-3"
                    backgroundImage="https://res.cloudinary.com/dkmtnqj5a/image/upload/v1680008233/powder_dvuxyu.jpg"
                    cld={cld}
                />

                {/* feature icon */}
                <FeatureIconSeven
                    spaceTopClass="pt-100"
                    spaceBottomClass="pb-25"
                />

                {/* brand logo */}
                <BrandLogoSliderFive spaceBottomClass="pt-70 pb-70" cld={cld} />
            </Layout>
        </Fragment>
    );
};

export default Home;