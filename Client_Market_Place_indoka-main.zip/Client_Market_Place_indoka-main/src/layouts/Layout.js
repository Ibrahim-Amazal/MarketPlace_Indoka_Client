import PropTypes from "prop-types";
import React, { Fragment } from "react";
import Header from "../wrappers/header/Header";
import FooterOne from "../wrappers/footer/FooterOne";
import ScrollToTop from "../components/scroll-to-top"

const Layout = ({ children }) => {
    return (
        <Fragment>
            <Header layout="container-fluid" />
            {children}
            <FooterOne
                backgroundColorClass="bg-gray"
                spaceTopClass="pt-100"
                spaceBottomClass="pb-70"
            />
            <ScrollToTop/>
        </Fragment>
    );
};

export default Layout;

Layout.propTypes = {
    children: PropTypes.node
};
