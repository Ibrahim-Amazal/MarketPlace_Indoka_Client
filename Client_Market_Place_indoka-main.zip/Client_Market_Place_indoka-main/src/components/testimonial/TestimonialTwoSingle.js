import PropTypes from "prop-types";
import {AdvancedImage} from '@cloudinary/react';
import React from "react";

const TestimonialTwoSingle = ({ data, cld }) => {
  return (
    <div
      className="single-testimonial single-testimonial--style2 text-center"
    >
      <AdvancedImage cldImg={cld.image(data.image).quality('auto')} />
      <p dangerouslySetInnerHTML={{ __html: data.content }}/>
      <div className="client-info">
        <h5>{data.customerName}</h5>
        <span>{data.title}</span>
      </div>
    </div>
  );
};

TestimonialTwoSingle.propTypes = {
  data: PropTypes.shape({})
};

export default TestimonialTwoSingle;
