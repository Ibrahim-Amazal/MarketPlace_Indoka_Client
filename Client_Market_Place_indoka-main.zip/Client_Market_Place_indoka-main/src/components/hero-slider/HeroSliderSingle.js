import PropTypes from "prop-types";
import { Link } from "react-router-dom";
import {AdvancedVideo} from "@cloudinary/react";


const HeroSliderSingle = ({ data, doClick }) => {
    return (
        <div
            className="single-slider-2 slider-height-2 d-flex align-items-center bg-img"
        >
            <video src={data.video} autoPlay loop muted/>
            <div className="container">
                <div className="row">
                    <div className="col-xl-12 col-lg-12 col-md-12 col-12">
                        <div className="slider-content-brown slider-content-2 slider-content-2--white slider-animated-1">
                            <h3
                                className="animated"
                                dangerouslySetInnerHTML={{ __html: data.title }}
                            />
                            <h1
                                className="animated"
                                dangerouslySetInnerHTML={{ __html: data.subtitle }}
                            />
                            <div className="slider-btn-brown btn-hover">
                                <Link
                                    className="animated"
                                    onClick={doClick}
                                >
                                    Apprendre plus
                                </Link>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

HeroSliderSingle.propTypes = {
    data: PropTypes.shape({})
};

export default HeroSliderSingle;
