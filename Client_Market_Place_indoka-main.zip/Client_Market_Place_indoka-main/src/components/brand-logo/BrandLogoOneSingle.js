import PropTypes from "prop-types";
import clsx from "clsx";
import {AdvancedImage} from "@cloudinary/react";

const BrandLogoOneSingle = ({ data, spaceBottomClass, cld }) => {
  return (
    <div className={clsx("single-brand-logo", spaceBottomClass)}>
      <AdvancedImage cldImg={cld.image(data.image).quality('auto')} />
    </div>
  );
};

BrandLogoOneSingle.propTypes = {
  data: PropTypes.shape({}),
  spaceBottomClass: PropTypes.string
};

export default BrandLogoOneSingle;
