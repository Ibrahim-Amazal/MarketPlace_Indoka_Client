import PropTypes from "prop-types";
import clsx from "clsx";

const SectionTitleImage = ({ spaceTopClass, spaceBottomClass, elem }) => {
    return (
        <div
            ref={elem}
            className="welcome-area"
            style={{ backgroundImage: 'url(https://res.cloudinary.com/dkmtnqj5a/image/upload/f_auto/v1680008286/pill_ofbmhd.jpg)' }}
            >
            <div className={clsx("glass", spaceTopClass, spaceBottomClass)}>
                <div className="container">
                    <div className="welcome-content text-center">
                        <h1 className="text-white" >LA VOIE INDOKA</h1>
                        <p className="text-white" >
                        INDOKA SARL est un leader dans le développement, la distribution et la fourniture à l'industrie 
                        marocaine des compléments alimentaires. Avec plus de 20 ans d'expérience, nous proposons des formes 
                        innovantes de dosage telles que les Gélules à Base de Plantes, les Softgels à Mâcher et les comprimés 
                        compressés pour répondre aux exigences des consommateurs en matière de produits plus sains, agréables 
                        et pratiques. Avec une bibliothèque de produits prêts à être commercialisés, des formes de dosage 
                        préférées par les consommateurs et un réseau mondial de fabrication, INDOKA peut aider les responsables
                        marketing à lancer et à approvisionner de manière fiable des compléments alimentaires différenciés plus 
                        rapidement, ainsi qu'à fournir le bon conseil pour enregistrer les produits auprès de l'Administration
                        Marocaine des Médicaments et de la Pharmacie.{" "}
                        </p>
                    </div>
                </div>
            </div>
        </div>
    );
};

SectionTitleImage.propTypes = {
    spaceBottomClass: PropTypes.string,
    spaceTopClass: PropTypes.string
};

export default SectionTitleImage;
