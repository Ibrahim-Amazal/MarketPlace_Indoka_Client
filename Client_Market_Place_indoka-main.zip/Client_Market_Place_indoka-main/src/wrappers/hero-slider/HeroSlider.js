
import { EffectFade } from 'swiper';
import Swiper, { SwiperSlide } from "../../components/swiper";
import heroSliderData from "../../data/hero-sliders/hero-slider-fourteen.json";
import HeroSliderSingle from "../../components/hero-slider/HeroSliderSingle";

const params = {
  effect: "fade",
  fadeEffect: {
    crossFade: true
  },
  modules: [EffectFade],
  loop: true,
  speed: 1000,
  navigation: false,
  autoHeight: false
};

const HeroSlider = ({ doClick }) => {
  return (
    <div className="slider-area">
      <div className="slider-active nav-style-1">
        <Swiper options={params}>
          {heroSliderData?.map((single, key) => (
            <SwiperSlide key={key}>
              <HeroSliderSingle data={single} doClick={doClick} />
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    </div>
  );
};

export default HeroSlider;
